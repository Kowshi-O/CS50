# Project 0

Web Programming with Python and JavaScript

## Project0 - an informative website

Teaches people about climate change.
